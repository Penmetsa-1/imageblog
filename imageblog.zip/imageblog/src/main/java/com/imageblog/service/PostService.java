// src/main/java/com/imageblog/service/PostService.java
package com.imageblog.service;

import com.imageblog.model.Post;
import com.imageblog.repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

@Service
public class PostService {
    
    @Autowired
    private PostRepository postRepository;
    
    private final String UPLOAD_DIR = "uploads/";
    
    public List<Post> getAllPosts() {
        return postRepository.findAllByOrderByCreatedAtDesc();
    }
    
    public Post getPostById(Long id) {
        return postRepository.findById(id).orElse(null);
    }
    
    public Post savePost(Post post, MultipartFile imageFile) throws IOException {
        if (!imageFile.isEmpty()) {
            String fileName = saveImage(imageFile);
            post.setImagePath(fileName);
        }
        return postRepository.save(post);
    }
    
    private String saveImage(MultipartFile imageFile) throws IOException {
        // Create uploads directory if it doesn't exist
        Path uploadPath = Paths.get(UPLOAD_DIR);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        
        // Generate unique file name
        String fileName = UUID.randomUUID().toString() + "_" + imageFile.getOriginalFilename();
        Path filePath = uploadPath.resolve(fileName);
        Files.copy(imageFile.getInputStream(), filePath);
        
        return fileName;
    }
    
    public void deletePost(Long id) {
        postRepository.deleteById(id);
    }
}