// src/main/java/com/imageblog/controller/PostController.java
package com.imageblog.controller;

import com.imageblog.model.Post;
import com.imageblog.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Controller
public class PostController {
    
    @Autowired
    private PostService postService;
    
    @GetMapping("/")
    public String home(Model model) {
        List<Post> posts = postService.getAllPosts();
        model.addAttribute("posts", posts);
        return "index";
    }
    
    @GetMapping("/post/new")
    public String showNewPostForm(Model model) {
        model.addAttribute("post", new Post());
        return "new-post";
    }
    
    @PostMapping("/post/save")
    public String savePost(@ModelAttribute Post post, 
                          @RequestParam("imageFile") MultipartFile imageFile) {
        try {
            postService.savePost(post, imageFile);
            return "redirect:/";
        } catch (IOException e) {
            e.printStackTrace();
            return "redirect:/post/new?error";
        }
    }
    
    @GetMapping("/post/{id}")
    public String viewPost(@PathVariable Long id, Model model) {
        Post post = postService.getPostById(id);
        model.addAttribute("post", post);
        return "view-post";
    }
    
    @GetMapping("/post/delete/{id}")
    public String deletePost(@PathVariable Long id) {
        postService.deletePost(id);
        return "redirect:/";
    }
}