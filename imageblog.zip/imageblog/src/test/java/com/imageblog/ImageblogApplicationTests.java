package com.imageblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageblogApplicationTests {

	@Test
	void contextLoads() {
	}

}
